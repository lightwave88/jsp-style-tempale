
module.exports = require('./TempalteAPI.js');