const $GM = require('./gmodules.js');
const $file = require('../file.js');
const $tool = require('../tool.js');
const $path = require('path');
const $util = require('util');
//------------------------------------------------------------------------------
/**
 * 把 template 內文
 * 形成 render_function
 */
class Compile {

    static getInstance(options) {
        return new Compile(options);
    }


    //--------------------------------------------------------------------------
    constructor(options = {}) {
        this.fn = Compile;
        this.userOptions = options;

        this.fileInfo = {
            file: null,
            content: null,
        };

        //------------------
        // 讓每個 compile 可以有不同的模組
        this.moduleClassMap = {
            "$page": null,
            "$out": null,
        };

        this.moduleMap = {};
        //------------------
        this._checkOptions();
    }
    //--------------------------------------------------------------------------
    // $page.include() 會用到
    setTemplateFile(file) {
        this.fileInfo.content = null;

        if (!$path.isAbsolute(file)) {
            file = $path.resolve(this.userOptions.include_dir, file);
        }

        this.fileInfo.file = file;
    }
    //--------------------------------------------------------------------------
    // 取得 renderFun
    compile() {
        debugger;

        const userOptions = this.userOptions;
        let res;
        const process = new CompileProcess(this);

        // 根據 async 而分流
        if (userOptions.sync == true) {
            // 發出同步 compile 進程
            let fn = process.run_sync();
            res = fn;
        } else {
            // 發出非同步 compile 進程
            // 原因在於 require(),include() 文本時
            // 采用非同步
            let promise = process.run();
            res = promise;
        }

        return res;
    }
    //--------------------------------------------------------------------------
    // 快捷
    display(data) {
        debugger;

        let res = this.compile();

        if (res instanceof Promise) {
            res = res.then((fn) => {
                return fn(data);
            });
        } else {
            let fn = res;
            res = fn(data);
        }
        return res;
    }
    //--------------------------------------------------------------------------
    // 擴展内建的功能模組
    expandClass(moduleName, $class) {
        this.moduleClassMap[moduleName] = $class;
    }
    //--------------------------------------------------------------------------
    // 擴展内建的功能模組
    expand(moduleName, obj) {
        this.moduleMap[moduleName] = obj;

    }

    //--------------------------------------------------------------------------
    // 確定 compile.options
    _checkOptions() {
        debugger;
        /**
         * options ={
         * context: 上下文
         * file: 文件位置,
         * content: 文件內文,
         * sync,
         * include_dir: include 的位置
         * }
         */
        const $config = $GM.get('config');

        let {
            content,
            sync,
            file,
            include_dir,
            context,
            string_template,
        } = this.userOptions;
        //------------------
        // 檢查 sync
        if (sync == null) {
            sync = !!$config.get('file_sync');
        }

        //------------------
        // 檢查 context
        if (context == null) {
            context = {};
        }
        //------------------
        // 檢查 string_template

        if (string_template == null) {
            string_template = !!$config.get("string_template");
        }
        //------------------
        // 檢查 include_dir
        if (include_dir == null) {
            include_dir = $config.get('include_dir');
        }

        if (include_dir != null) {
            if (!$path.isAbsolute(include_dir)) {
                throw new Error(`include_dir(${include_dir}) must be absolutePath`);
            }
        }
        //------------------
        if (content == null) {
            /**
             * 檢查 file
             * 若 file 是相對路徑
             */
            if (file != null && !$path.isAbsolute(file)) {
                if (include_dir == null) {
                    throw new Error(`no set include_dir`);
                }
                file = $path.resolve(include_dir, file);
            }
        }
        //------------------

        (file == null) || (this.fileInfo.file = file);
        (content == null) || (this.fileInfo.content = content);

        this.userOptions = {
            sync,
            include_dir,
            context,
            string_template,
        };
    }
}

module.exports = Compile;


// compile 的進程
// 獨立每個 compile 的進程
// 避免不同的 compile 過程造成參數干擾
class CompileProcess {

    constructor(parent) {
        this.parent = parent;

        this.userOptions = Object.assign({}, parent.userOptions);

        this.fileInfo = Object.assign({}, parent.fileInfo);

        // 模板内部需要實例化的模組
        this.modules = {};

        this.moduleContent;
    }
    //--------------------------------------------------------------------------
    async run() {
        debugger;

        /**
         * 把 html_content 拆成命令
         * 會因為<js:include>有 sync, async 之分
         */
        const splite_tag = $GM.get('splite_tag');
        // async
        let nodeList = await splite_tag.main(html_content, options);

        let command = '';
        nodeList.forEach((node) => {
            command += node.$$$printCommand();
        });

        debugger;

        // test
        return nodeList;
        //-----------------------

        let fn = this._generateFun(command);
        return fn;
    }
    //--------------------------------------------------------------------------
    run_sync() {
        debugger;

        let { file, content } = this.fileInfo;
        //-----------------------
        /**
         * 若使用者有指定 template 檔案
         */
        if (file != null) {
            if (!$file.file_exists_sync(file)) {
                throw new Error(`file(${file}) no exists`);
            }
            // 取得 template.content
            content = $file.file_get_contents_sync(file);
        }

        if (typeof (content) != "string") {
            throw new Error(`no get template.content`);
        }
        //-----------------------
        /**
         * 把 html_content 拆成命令
         * 會因為<js:include>而有 sync, async 之分
         */
        const splite_tag = $GM.get('splite_tag');
        let nodeList = splite_tag.main_sync(content, this.userOptions);

        debugger;
        console.dir(nodeList);

        let command = '';
        nodeList.forEach((node) => {
            console.log(typeof node);

            // 把 nodeList 轉為 command
            command += node.$$$printCommand();
        });

        console.log(`command=\n${command}`);

        // return command;
        //-----------------------
        debugger;
        // 做成 render_fun
        let fn = this._generateFun_sync(command);
        return fn;
    }
    //--------------------------------------------------------------------------
    // 取得 render 需要的 module
    _getCompileModule() {

        let content = '';
        const module = this.modules;
        const moduleClassMap = this.parent.moduleClassMap;
        const moduleMap = this.parent.moduleMap;
        const userOptions = this.parent.userOptions;
        //-------------
        moduleClassMap["$out"] = $GM.get("out");
        moduleClassMap["$page"] = $GM.get("page");
        //-------------

        // module=>object
        let keyList = Object.getOwnPropertyNames(moduleMap);

        keyList.forEach((key) => {
            const obj = moduleMap[key];
            module[key] = obj;
            content += `const ${key} = $module["${key}"];\n`;
        });

        //module=>class
        keyList = Object.getOwnPropertyNames(moduleClassMap);

        keyList.forEach((key) => {
            if (key in moduleMap) {
                return;
            }
            const $class = moduleClassMap[key];
            const obj = new $class(userOptions);
            module[key] = obj;
            content += `const ${key} = $module["${key}"];\n`;
        });

        //-------------
        const $page = module["$page"];

        // 暫時性做法
        $page.$$$setModule(module);
        $page.$$$setModule("compile", this.parent);
        //-------------
        content += "$module = null;\n";

        this.moduleContent = content;
    }

    _generateFun(command) {

    }
    //--------------------------------------------------------------------------
    // 做成 render_fun
    _generateFun_sync(command) {
        // 取得 render 需要的 module

        this._getCompileModule();

        const moduleContent = this.moduleContent;
        const modules = this.modules;
        const userOptions = this.parent.userOptions;

        // 上下文
        const context = userOptions.context;

        // 内置的資料
        const $data_1 = {};

        //------------------

        function renderFun(variable) {
            debugger;

            // 模板内變數
            variable = Object.assign({}, $data_1, variable);

            // 變數
            let variable_content = '';

            Object.getOwnPropertyNames(variable).forEach((key) => {
                variable_content +=
                    `let ${key} = $variable["${key}"];\n`;
            });

            variable_content += `$variable = null;\n`;

            debugger;
            //------------------
            let fun_content = `
            debugger;

            // 模組
            ${moduleContent}

            // 變數
            ${variable_content}
            //------------------
            ${command}
            //------------------
            return $out.result();`;

            console.log('fn.content=%s', fun_content);

            const fun = new Function('$module', '$variable', fun_content);

            debugger;

            return fun.call(context, modules, variable);
        }
        //------------------
        renderFun.assign = function (key, value) {
            $data_1[key] = value;
        };

        renderFun.clear = function () {
            Object.getOwnPropertyNames($data_1).forEach((k) => {
                delete $data_1[k];
            });
        };

        return renderFun;
    }
    //--------------------------------------------------------------------------

}