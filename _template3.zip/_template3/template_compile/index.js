const $GM = require('./gmodules.js');

module.exports = $GM.get('compile');




