// 内文的操作
// 把命令標簽化
// 功能只能操作内文的排序
// 如 jsp 的 <c:forEach>
class ContentOperator_ABS {

}