const $GM = require('./gmodules.js');
const $file = require('../file.js');
//------------------------------------------------------------------------------
/**
 * 負責輸出
 */
class Output {
    constructor(options = {}) {

        // 預設 false
        options.sync = !!options.sync;

        Object.defineProperty(this, '$$$options', {
            value: options,
            configurable: false,
            writable: false,
            enumerable: false,
        });

        // this['$$$contentList']
        // 要輸出的文本內容
        Object.defineProperty(this, '$$$contentList', {
            enumerable: false,
            writable: false,
            configurable: false,
            value: []
        });
    }
    //--------------------------------------------------------------------------
    push(html) {
        if (typeof (html) != 'string') {
            throw new TypeError(`output must be string`);
        }
        this.$$$contentList.push(html);
    }
    //--------------------------------------------------------------------------
    // 取得最後結果
    result() {
        return this.$$$contentList.join('');
    }
    //--------------------------------------------------------------------------
    print(html) {
        html = Output.print(html);
        this.push(html);
    }
    //--------------------------------------------------------------------------
    escape(html) {
        html = Output.print(html);

        // to do

        this.push(html);
    }

    //--------------------------------------------------------------------------
    // 動態 include
    // 可以是 sync, async
    include(filepath, data) {
        debugger;
        const $compile = $GM.get('compile');

        const options = Object.assObject.assign({}, this.$$$options);
        delete options.content;
        options.file = filepath;

        /**
         * 讀取 file.content
         * 並解析成 render_fun
         */
        let res = $compile(options);

        if (res instanceof Promise) {
            debugger;
            let p = res.then((fn) => {
                return fn(data);
            });

            p = p.then((content) => {
                this.push(content);
            });

            return p;
        } else {
            debugger;
            let fn = res;
            let content = fn(data);
            this.push(content);
        }
    }
    //--------------------------------------------------------------------------
    static print(html) {

        if (typeof html == 'undefined') {
            html = 'undefined';
        } else if (typeof html == 'object') {
            if (html === null) {
                html = 'null';
            } else {
                html = JSON.stringify(html);
            }
        } else {
            try {
                html += '';
            } catch (err) {
                html = err.toString();
            }
        }
        return html;
    }
    //--------------------------------------------------------------------------
}
module.exports = Output;
